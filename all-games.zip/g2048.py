# 2048 for the TI-84 Evo
# Keys: arrows = slide all tiles, clear = quit
import random
from ti_draw import clear, set_color, draw_text
from ti_draw import fill_rect as ti_fill_rect
try:
    from ti_draw import get_screen_dim
    SW, SH = get_screen_dim()
except:
    SW, SH = 319, 209

# Keep every box inside the screen and never stop the game over one box.
# The Evo draws boxes 1 pixel too small, so we ask for 1 pixel more.
def fill_rect(x, y, w, h):
    if x < 0:
        w, x = w + x, 0
    if y < 0:
        h, y = h + y, 0
    w, h = min(w, SW - x), min(h, SH - y)
    if w > 0 and h > 0:
        try:
            ti_fill_rect(x, y, w + 1, h + 1)
        except:
            pass
# Draw in a hidden buffer and show the finished picture at once: no flicker
try:
    from ti_draw import use_buffer, paint_buffer
    use_buffer()
except:
    paint_buffer = None
try:
    from ti_system import get_key as read_key
except:
    from ti_system import getKey as read_key
# On the Evo get_key wants one number. Find out once at the start.
try:
    read_key()
    key = read_key
except TypeError:
    def key():
        return read_key(0)
try:
    from ti_system import store_list, recall_list
except:
    store_list = recall_list = None
try:
    from time import sleep
except:
    from ti_system import sleep

LEFT = (2, 24)
RIGHT = (1, 26)
UP = (3, 25)
DOWN = (4, 34)
OK = (5, 105)                 # enter
QUIT = (9, 45)                # clear

T = 48                        # tile size with gap
X0 = 8
Y0 = (SH - 4 * T) // 2
TX = X0 + 4 * T + 12          # text panel (black, so text is fine)
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
BACK = (187, 173, 160)        # the board
DARK = (119, 110, 101)        # numbers on light tiles
COLORS = {0: (205, 193, 180), 2: (238, 228, 218), 4: (237, 224, 200),
          8: (242, 177, 121), 16: (245, 149, 99), 32: (246, 124, 95),
          64: (246, 94, 59), 128: (237, 207, 114), 256: (237, 204, 97),
          512: (237, 200, 80), 1024: (237, 197, 63), 2048: (237, 194, 46)}

# Digits as 3 x 5 block pictures (text can't sit on coloured tiles)
DIGITS = ["###", "#.#", "#.#", "#.#", "###",
          ".#.", "##.", ".#.", ".#.", "###",
          "##.", "..#", ".#.", "#..", "###",
          "##.", "..#", ".#.", "..#", "##.",
          "#.#", "#.#", "###", "..#", "..#",
          "###", "#..", "##.", "..#", "##.",
          ".##", "#..", "###", "#.#", "###",
          "###", "..#", ".#.", ".#.", ".#.",
          "###", "#.#", "###", "#.#", "###",
          "###", "#.#", "###", "..#", "##."]

grid = [0] * 16

def paint():
    if paint_buffer:
        paint_buffer()

def write(x, y, s):                    # text that can never stop the game
    try:
        draw_text(x, y, s)
    except:
        pass

def wait_for(keys):
    paint()
    while True:
        k = key()
        if k in keys:
            return k
        sleep(0.05)

def text(row, s, col=WHITE):           # right panel, rows 30 px high
    set_color(*BLACK)
    fill_rect(TX, row * 30, SW - TX, 29)
    set_color(*col)
    write(TX, row * 30 + 22, s)

def load_best():
    try:
        return int(recall_list("G2048")[0])
    except:
        return 0

def save_best(n):
    try:
        store_list("G2048", [n])
    except:
        pass

def digit(d, x, y, p):
    for r in range(5):
        row = DIGITS[d * 5 + r]
        c = 0
        while c < 3:                   # each run of blocks as one box
            if row[c] == "#":
                e = c
                while e < 3 and row[e] == "#":
                    e += 1
                fill_rect(x + c * p, y + r * p, (e - c) * p, p)
                c = e
            else:
                c += 1

def tile(i):
    v = grid[i]
    x, y = X0 + (i % 4) * T, Y0 + (i // 4) * T
    set_color(*COLORS.get(v, (60, 58, 50)))
    fill_rect(x + 2, y + 2, T - 5, T - 5)
    if v:
        s = str(v)
        p = 3 if len(s) <= 3 else 2            # smaller blocks for 4 digits
        w = len(s) * 4 * p - p
        set_color(*(DARK if v <= 4 else WHITE))
        for n in range(len(s)):
            digit(int(s[n]), x + (T - w) // 2 + n * 4 * p, y + (T - 5 * p) // 2, p)

# Slide one line of 4 tiles toward its start. Returns new line and points.
def slide(line):
    nums = [v for v in line if v]
    out, pts, i = [], 0, 0
    while i < len(nums):
        if i + 1 < len(nums) and nums[i] == nums[i + 1]:
            out.append(nums[i] * 2)            # two equal tiles merge
            pts += nums[i] * 2
            i += 2
        else:
            out.append(nums[i])
            i += 1
    return out + [0] * (4 - len(out)), pts

# The 4 lines for each direction, listed from the side the tiles slide to
LINES = {}
for d in ("L", "R", "U", "D"):
    LINES[d] = []
    for k in range(4):
        if d == "L":
            LINES[d].append([k * 4 + j for j in range(4)])
        elif d == "R":
            LINES[d].append([k * 4 + 3 - j for j in range(4)])
        elif d == "U":
            LINES[d].append([j * 4 + k for j in range(4)])
        else:
            LINES[d].append([(3 - j) * 4 + k for j in range(4)])

def move(d):
    pts, moved = 0, False
    for idx in LINES[d]:
        old = [grid[i] for i in idx]
        new, p = slide(old)
        pts += p
        if new != old:
            moved = True
            for n in range(4):
                grid[idx[n]] = new[n]
    return moved, pts

def add_tile():
    empty = [i for i in range(16) if grid[i] == 0]
    if empty:
        grid[random.choice(empty)] = 4 if random.random() < 0.1 else 2

def can_move():
    for i in range(16):
        if grid[i] == 0:
            return True
        if i % 4 < 3 and grid[i] == grid[i + 1]:
            return True
        if i < 12 and grid[i] == grid[i + 4]:
            return True
    return False

def start_screen(best):
    clear()
    set_color(*BLACK)
    fill_rect(0, 0, SW, SH)
    x = SW // 2 - 80
    set_color(*COLORS[2048])
    write(x + 40, 25, "2048")
    set_color(*WHITE)
    write(x, 55, "Best " + str(best))
    help = ["ARROWS: slide", "Same numbers merge", "Make a 2048 tile!", "CLEAR: quit"]
    for i in range(len(help)):
        write(x, 90 + i * 25, help[i])
    set_color(230, 200, 0)
    write(x, 200, "ENTER: start")
    return wait_for(OK + QUIT) in OK

def game(best):
    for i in range(16):
        grid[i] = 0
    add_tile()
    add_tile()
    clear()
    set_color(*BLACK)
    fill_rect(0, 0, SW, SH)
    set_color(*BACK)
    fill_rect(X0, Y0, 4 * T, 4 * T)
    for i in range(16):
        tile(i)
    score, reached = 0, False
    text(0, "Score")
    text(1, "0")
    text(2, "Best")
    text(3, str(best))
    text(6, "CLEAR:quit")
    while True:
        paint()
        k = key()
        if not k:
            sleep(0.03)
            continue
        if k in QUIT:
            return score, True
        d = "L" if k in LEFT else "R" if k in RIGHT else "U" if k in UP else "D" if k in DOWN else ""
        if not d:
            continue
        before = grid[:]
        moved, pts = move(d)
        if not moved:
            continue
        add_tile()
        for i in range(16):                    # only redraw tiles that changed
            if grid[i] != before[i]:
                tile(i)
        if pts:
            score += pts
            text(1, str(score))
        if not reached and 2048 in grid:
            reached = True
            text(4, "2048!", COLORS[2048])
        if not can_move():
            return score, False

# --- start ---
best = load_best()
if start_screen(best):
    while True:
        score, quit = game(best)
        if score > best:
            best = score
            save_best(best)
            text(3, str(best))
            text(4, "NEW BEST!", COLORS[2048])
        else:
            text(4, "GAME OVER")
        if quit:
            break
        text(5, "ENTER:again")
        if wait_for(OK + QUIT) in QUIT:
            break
paint()
