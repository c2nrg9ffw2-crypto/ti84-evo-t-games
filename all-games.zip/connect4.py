# Connect Four for the TI-84 Evo
# Get 4 of your discs in a row: across, down or diagonal.
# Keys: left/right = choose column, enter = drop, clear = quit
import random
from ti_draw import clear, set_color, draw_text
from ti_draw import fill_rect as ti_fill_rect
try:
    from ti_draw import get_screen_dim
    SW, SH = get_screen_dim()
except:
    SW, SH = 319, 209

# Keep every box inside the screen and never stop the game over one box.
# The Evo draws boxes 1 pixel too small, so we ask for 1 pixel more.
def fill_rect(x, y, w, h):
    if x < 0:
        w, x = w + x, 0
    if y < 0:
        h, y = h + y, 0
    w, h = min(w, SW - x), min(h, SH - y)
    if w > 0 and h > 0:
        try:
            ti_fill_rect(x, y, w + 1, h + 1)
        except:
            pass
# Draw in a hidden buffer and show the finished picture at once: no flicker
try:
    from ti_draw import use_buffer, paint_buffer
    use_buffer()
except:
    paint_buffer = None
try:
    from ti_system import get_key as read_key
except:
    from ti_system import getKey as read_key
# On the Evo get_key wants one number. Find out once at the start.
try:
    read_key()
    key = read_key
except TypeError:
    def key():
        return read_key(0)
try:
    from ti_system import store_list, recall_list
except:
    store_list = recall_list = None
try:
    from time import sleep
except:
    from ti_system import sleep

LEFT = (2, 24)
RIGHT = (1, 26)
UP = (3, 25)
DOWN = (4, 34)
OK = (5, 105)                 # enter
QUIT = (9, 45)                # clear

COLS, ROWS = 7, 6
C = 29                        # cell size
X0 = 4
Y0 = SH - ROWS * C - 3        # room above the board for the waiting disc
TX = X0 + COLS * C + 8        # text panel (black, so text is fine)
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
BLUE = (20, 60, 200)
YELLOW = (255, 220, 0)
DISC = {0: BLACK, 1: (230, 30, 30), 2: YELLOW}   # 1 = red, 2 = yellow
NAME = {1: "Red", 2: "Yellow"}
# A round disc made of 5 x 5 blocks of 4 pixels (20 px), with blue around it
ROUND = [".###.", "#####", "#####", "#####", ".###."]
GAP = (C - 20) // 2           # blue edge around each hole

board = [[0] * COLS for r in range(ROWS)]        # row 0 is the top

def paint():
    if paint_buffer:
        paint_buffer()

def write(x, y, s):                    # text that can never stop the game
    try:
        draw_text(x, y, s)
    except:
        pass

def wait_for(keys):
    paint()
    while True:
        k = key()
        if k in keys:
            return k
        sleep(0.05)

def text(row, s, col=WHITE):           # right panel, rows 30 px high
    set_color(*BLACK)
    fill_rect(TX, row * 30, SW - TX, 29)
    set_color(*col)
    write(TX, row * 30 + 22, s)

# Wins are saved in the calculator list CONN4: [red wins, yellow wins, draws]
def load_stats():
    try:
        l = recall_list("CONN4")
        return [int(l[0]), int(l[1]), int(l[2])]
    except:
        return [0, 0, 0]

def save_stats(s):
    try:
        store_list("CONN4", s)
    except:
        pass

def disc(x, y, col):
    set_color(*col)
    for r in range(5):
        row = ROUND[r]
        a = row.index("#")
        b = row.rindex("#") + 1
        fill_rect(x + a * 4, y + r * 4, (b - a) * 4, 4)

def cell(r, c):
    x, y = X0 + c * C, Y0 + r * C
    set_color(*BLUE)
    fill_rect(x, y, C, C)
    disc(x + GAP, y + GAP, DISC[board[r][c]])

def hover(c, p):                       # the disc waiting above the board
    set_color(*BLACK)
    fill_rect(X0, 0, COLS * C, Y0)
    if p:
        disc(X0 + c * C + GAP, Y0 - C + GAP, DISC[p])

def drop_row(c):                       # lowest free row, or -1 if full
    return free[c]

def wins_at(r, c):                     # does the disc at r, c make 4 in a row?
    p = board[r][c]
    for dr, dc in ((0, 1), (1, 0), (1, 1), (1, -1)):
        n = 1
        for s in (1, -1):
            rr, cc = r + dr * s, c + dc * s
            while 0 <= rr < ROWS and 0 <= cc < COLS and board[rr][cc] == p:
                n += 1
                rr, cc = rr + dr * s, cc + dc * s
        if n >= 4:
            return True
    return False

# ---------- computer player ----------
# Looks a few moves ahead (alpha-beta search) and scores every group of 4.
ORDER = [3, 2, 4, 1, 5, 0, 6]          # middle columns first
WINDOWS = []
for r in range(ROWS):
    for c in range(COLS):
        for dr, dc in ((0, 1), (1, 0), (1, 1), (1, -1)):
            cells = [(r + dr * i, c + dc * i) for i in range(4)]
            if all(0 <= a < ROWS and 0 <= b < COLS for a, b in cells):
                WINDOWS.append(cells)
WIN = 100000

# Running score: instead of reading all 69 groups of 4 for every position,
# we keep the score up to date. Placing or removing a disc only changes the
# groups of 4 that touch that square (at most 13). Same score, much faster.
MINE = (0, 0, 2, 5, 0)                 # my 0..4 discs in a group with none of theirs
THEIRS = (0, 0, 2, 4, 0)               # their discs in a group with none of mine
CELLW = [[] for i in range(ROWS * COLS)]          # groups of 4 through each square
for i in range(len(WINDOWS)):
    for r, c in WINDOWS[i]:
        CELLW[r * COLS + c].append(i)
count = [None, [0] * len(WINDOWS), [0] * len(WINDOWS)]   # discs per group, per player
total = [0, 0, 0]                      # total[1] = points for red, total[2] for yellow
free = [ROWS - 1] * COLS               # lowest free row per column, -1 = full

def wval(m, o):
    if o == 0:
        return MINE[m]
    if m == 0:
        return -THEIRS[o]
    return 0

# Ready-made tables: points of a group with a red and b yellow discs,
# at index a * 5 + b. V1 for red's view, V2 for yellow's view.
V1 = [wval(a, b) for a in range(5) for b in range(5)]
V2 = [wval(b, a) for a in range(5) for b in range(5)]

def put(r, c, p):                      # place disc p (1 or 2), or 0 to remove
    old = board[r][c]
    c1, c2 = count[1], count[2]
    add = count[p] if p else None
    sub = count[old] if old else None
    t1 = t2 = 0
    for i in CELLW[r * COLS + c]:
        k = c1[i] * 5 + c2[i]
        t1 -= V1[k]
        t2 -= V2[k]
        if sub:
            sub[i] -= 1
        if add:
            add[i] += 1
        k = c1[i] * 5 + c2[i]
        t1 += V1[k]
        t2 += V2[k]
    if c == 3:                         # discs in the middle column count extra
        d = (0, 3, -3)[p] - (0, 3, -3)[old]
        t1 += d
        t2 -= d
    total[1] += t1
    total[2] += t2
    board[r][c] = p
    free[c] = r - 1 if p else r        # next free row in this column

def reset():
    for r in range(ROWS):
        board[r] = [0] * COLS
    for i in range(len(WINDOWS)):
        count[1][i] = count[2][i] = 0
    total[1] = total[2] = 0
    for c in range(COLS):
        free[c] = ROWS - 1

def points(me):                        # + is good for me, - for the other player
    return total[me]

def search(me, depth, alpha, beta):
    if depth == 0:
        return points(me)
    best, any_move = -WIN * 2, False
    for c in ORDER:
        r = drop_row(c)
        if r < 0:
            continue
        any_move = True
        put(r, c, me)
        if wins_at(r, c):
            v = WIN + depth                # win sooner is better
        else:
            v = -search(3 - me, depth - 1, -beta, -alpha)
        put(r, c, 0)
        if v > best:
            best = v
        if best > alpha:
            alpha = best
        if alpha >= beta:
            break
    return best if any_move else 0          # board full: draw

# level 1 = easy, 2 = medium, 3 = hard
def ai_move(me, level):
    free = [c for c in ORDER if drop_row(c) >= 0]
    if level == 1 and random.random() < 0.3:
        return random.choice(free)
    depth = (1, 2, 4)[level - 1]        # moves it looks ahead (even numbers work best)
    best, move = -WIN * 3, free[0]
    for c in free:
        r = drop_row(c)
        put(r, c, me)
        if wins_at(r, c):
            put(r, c, 0)
            return c
        v = -search(3 - me, depth - 1, -WIN * 3, WIN * 3)
        put(r, c, 0)
        v += random.random() * (6 if level == 1 else 1)
        if v > best:
            best, move = v, c
    return move

# ---------- screens ----------
def menu(options, choice, hint):
    x = SW // 2 - 80
    set_color(*BLACK)
    fill_rect(0, 64, SW, SH - 64)
    set_color(*WHITE)
    write(x, 202, hint)
    while True:
        for i in range(len(options)):
            set_color(*BLACK)
            fill_rect(x - 20, 64 + i * 28, 200, 27)
            set_color(*(YELLOW if i == choice else (150, 150, 150)))
            write(x, 90 + i * 28, ("> " if i == choice else "  ") + options[i])
        k = wait_for(UP + DOWN + OK + QUIT)
        if k in QUIT:
            return -1
        if k in OK:
            return choice
        if k in UP:
            choice = (choice - 1) % len(options)
        if k in DOWN:
            choice = (choice + 1) % len(options)

# Returns 0-2 = computer level (Easy, Medium, Hard), 3 = 2 players, -1 = quit
def start_screen(stats):
    clear()
    set_color(*BLACK)
    fill_rect(0, 0, SW, SH)
    x = SW // 2 - 80
    set_color(*DISC[1])
    write(x, 25, "CONNECT FOUR")
    set_color(*WHITE)
    write(x, 55, "Red " + str(stats[0]) + "  Yellow " + str(stats[1]) + "  Draw " + str(stats[2]))
    while True:
        p = menu(["1 player", "2 players"], 0, "UP/DOWN + ENTER")
        if p < 0:
            return -1
        if p == 1:
            return 3
        level = menu(["Easy", "Medium", "Hard"], 1, "CLEAR: back")
        if level >= 0:
            return level

def game(mode):                        # returns 1 red, 2 yellow, 3 draw, 0 quit
    reset()
    clear()
    set_color(*BLACK)
    fill_rect(0, 0, SW, SH)
    for r in range(ROWS):
        for c in range(COLS):
            cell(r, c)
    text(0, "CONNECT 4")
    text(5, "ENTER:drop")
    text(6, "CLEAR:quit")
    col, turn, placed = 3, 1, 0
    while True:
        computer = mode < 3 and turn == 2
        text(2, NAME[turn], DISC[turn])
        text(3, "thinking" if computer else "your turn")
        if computer:
            hover(col, 0)
            paint()
            c = ai_move(2, mode + 1)
        else:
            hover(col, turn)
            paint()
            while True:
                k = key()
                if not k:
                    sleep(0.03)
                    continue
                if k in QUIT:
                    return 0
                if k in LEFT and col > 0:
                    col -= 1
                elif k in RIGHT and col < COLS - 1:
                    col += 1
                elif k in OK and drop_row(col) >= 0:
                    break
                hover(col, turn)
                paint()
            c = col
        r = drop_row(c)
        put(r, c, turn)
        cell(r, c)
        placed += 1
        if wins_at(r, c):
            hover(col, 0)
            return turn
        if placed == ROWS * COLS:
            hover(col, 0)
            return 3
        turn = 3 - turn

# --- start ---
stats = load_stats()
mode = start_screen(stats)
while mode >= 0:
    w = game(mode)
    if w == 0:
        break
    stats[w - 1] += 1
    save_stats(stats)
    text(2, {1: "Red", 2: "Yellow", 3: "Draw!"}[w], DISC.get(w, WHITE))
    text(3, "wins!" if w < 3 else "")
    text(5, "ENTER:again")
    if wait_for(OK + QUIT) in QUIT:
        break
paint()
