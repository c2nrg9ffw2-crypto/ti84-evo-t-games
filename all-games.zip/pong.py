# Pong for the TI-84 Evo
# Keys: tap up/down = glide your paddle, 2nd = pause, clear = quit
import random
from math import sqrt
from ti_draw import clear, set_color, draw_text
from ti_draw import fill_rect as ti_fill_rect
try:
    from ti_draw import get_screen_dim
    SW, SH = get_screen_dim()
except:
    SW, SH = 319, 209

# Keep every box inside the screen and never stop the game over one box.
# The Evo draws boxes 1 pixel too small, so we ask for 1 pixel more.
def fill_rect(x, y, w, h):
    if x < 0:
        w, x = w + x, 0
    if y < 0:
        h, y = h + y, 0
    w, h = min(w, SW - x), min(h, SH - y)
    if w > 0 and h > 0:
        try:
            ti_fill_rect(x, y, w + 1, h + 1)
        except:
            pass
# Pong draws straight onto the screen (no hidden buffer). It only changes a few
# small boxes per step, and copying the whole buffer every step was so slow
# that the ball jumped far and showed twice.
paint_buffer = None
try:
    from ti_system import get_key as read_key
except:
    from ti_system import getKey as read_key
# On the Evo get_key wants one number. Find out once at the start.
try:
    read_key()
    key = read_key
except TypeError:
    def key():
        return read_key(0)
try:
    from ti_system import store_list, recall_list
except:
    store_list = recall_list = None
try:
    from time import sleep
except:
    from ti_system import sleep
# Tidy the memory between points, so Python never has to stop for it
# in the middle of a rally (that made the ball hiccup)
try:
    import gc
except:
    gc = None

UP = (3, 25)
DOWN = (4, 34)
OK = (5, 105)                 # enter
PAUSE = (21, 22)              # 2nd, mode
QUIT = (9, 45)                # clear

TOP = 30                      # field starts below the score bar
PW, PH = 5, 36                # paddle size
BALL = 8
STEP = 30                     # one tap glides the paddle this far
WIN_SCORE = 7
F = 16                        # ball position is kept in 1/16 pixels
SPEED = 4 * F                 # ball speed at the start (4 pixels per step)
SPEEDUP = F // 3              # each hit makes it this much faster
MAXV = 9 * F                  # top speed (more could jump past a paddle)
CPU_SPEED = 3                 # how fast the computer paddle moves
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
YOU = (0, 220, 0)
CPU = (230, 60, 60)
LX, RX = 6, SW - 6 - PW       # paddle x positions

def paint():
    if paint_buffer:
        paint_buffer()

def write(x, y, s):                    # text that can never stop the game
    try:
        draw_text(x, y, s)
    except:
        pass

def wait_for(keys):
    paint()
    while True:
        k = key()
        if k in keys:
            return k
        sleep(0.05)

# Wins are saved in the calculator list PONG: [your wins, computer wins]
def load_stats():
    try:
        l = recall_list("PONG")
        return [int(l[0]), int(l[1])]
    except:
        return [0, 0]

def save_stats(s):
    try:
        store_list("PONG", s)
    except:
        pass

def bar(you, cpu, msg=""):
    set_color(*BLACK)
    fill_rect(0, 0, SW, TOP - 3)
    set_color(*YOU)
    write(6, 20, "You " + str(you))
    set_color(*CPU)
    write(SW - 70, 20, "CPU " + str(cpu))
    if msg:
        set_color(*WHITE)
        write(SW // 2 - 45, 20, msg)

# Move a paddle by only changing its ends: erase a thin strip on one end,
# draw one on the other. Redrawing the whole paddle made it flicker.
def paddle(x, y_old, y_new, col):
    d = y_new - y_old
    if abs(d) >= PH:                   # big jump: redraw it all
        set_color(*BLACK)
        fill_rect(x, y_old, PW, PH)
        set_color(*col)
        fill_rect(x, y_new, PW, PH)
    elif d > 0:                        # moving down
        set_color(*BLACK)
        fill_rect(x, y_old, PW, d)
        set_color(*col)
        fill_rect(x, y_old + PH, PW, d)
    elif d < 0:                        # moving up
        set_color(*BLACK)
        fill_rect(x, y_new + PH, PW, -d)
        set_color(*col)
        fill_rect(x, y_new, PW, -d)

# Erase only the part of the old ball that the new ball doesn't cover,
# so there is never a moment without a ball (that made it flicker)
def erase_old(ox, oy, x, y):
    set_color(*BLACK)
    if abs(x - ox) >= BALL or abs(y - oy) >= BALL:
        fill_rect(ox, oy, BALL, BALL)        # no overlap: erase it all
        return
    if x > ox:
        fill_rect(ox, oy, x - ox, BALL)
    elif x < ox:
        fill_rect(x + BALL, oy, ox - x, BALL)
    if y > oy:
        fill_rect(ox, oy, BALL, y - oy)
    elif y < oy:
        fill_rect(ox, y + BALL, BALL, oy - y)

# Where the ball hits the paddle sets the angle: -1 top edge ... 1 bottom edge
def angle(y, paddle_y):
    a = (y + BALL / 2 - paddle_y - PH / 2) / (PH / 2 + BALL / 2)
    return max(-1, min(1, a))

# Ball direction with the same total speed sp, whatever the angle
def aim(sp, a, right):
    vy = int(sp * a * 0.7)
    vx = int(sqrt(sp * sp - vy * vy))
    return (vx if right > 0 else -vx), vy

def start_screen(stats):
    clear()
    set_color(*BLACK)
    fill_rect(0, 0, SW, SH)
    x = SW // 2 - 80
    set_color(*YOU)
    write(x + 40, 25, "PONG")
    set_color(*WHITE)
    write(x, 55, "You " + str(stats[0]) + "  CPU " + str(stats[1]))
    help = ["Tap UP/DOWN: glide", "First to " + str(WIN_SCORE) + " wins",
            "2ND: pause", "CLEAR: quit"]
    for i in range(len(help)):
        write(x, 90 + i * 25, help[i])
    set_color(230, 200, 0)
    write(x, 200, "ENTER: start")
    return wait_for(OK + QUIT) in OK

def game():
    clear()
    set_color(*BLACK)
    fill_rect(0, 0, SW, SH)
    set_color(90, 90, 90)
    fill_rect(0, TOP - 3, SW, 2)            # top wall
    you, cpu = 0, 0
    py = cy = (TOP + SH - PH) // 2          # paddle tops
    target = py
    set_color(*YOU)
    fill_rect(LX, py, PW, PH)
    set_color(*CPU)
    fill_rect(RX, cy, PW, PH)
    serve = 1                               # ball goes right first
    while you < WIN_SCORE and cpu < WIN_SCORE:
        bar(you, cpu)
        bx, by = (SW // 2) * F, ((TOP + SH) // 2) * F
        if gc:
            gc.collect()
        sp = SPEED                          # speed resets after every point
        aim_off = random.randint(-14, 14)   # computer doesn't always hit dead centre
        vx, vy = aim(sp, random.random() - 0.5, serve)
        set_color(*WHITE)
        fill_rect(bx // F, by // F, BALL, BALL)
        paint()
        sleep(0.6)
        while True:
            k = key()
            if k in QUIT:
                return you, cpu, True
            if k in PAUSE:
                bar(you, cpu, "PAUSED")
                if wait_for(PAUSE + OK + QUIT) in QUIT:
                    return you, cpu, True
                bar(you, cpu)
            if k in UP:
                target = max(TOP, target - STEP)
            if k in DOWN:
                target = min(SH - PH, target + STEP)
            # your paddle glides to its target
            if py != target:
                ny = py + max(-5, min(5, target - py))
                paddle(LX, py, ny, YOU)
                py = ny
            # computer paddle follows the ball, but not too fast
            want = by // F + BALL // 2 - PH // 2 + aim_off if vx > 0 else (TOP + SH - PH) // 2
            ny = cy + max(-CPU_SPEED, min(CPU_SPEED, want - cy))
            ny = max(TOP, min(SH - PH, ny))
            if ny != cy:
                paddle(RX, cy, ny, CPU)
                cy = ny
            # move the ball
            ox, oy = bx // F, by // F
            bx, by = bx + vx, by + vy
            if by < TOP * F or by > (SH - BALL) * F:   # bounce off top/bottom
                vy = -vy
                by = max(TOP * F, min((SH - BALL) * F, by))
            x, y = bx // F, by // F
            if vx < 0 and x <= LX + PW and x >= LX - BALL and py - BALL < y < py + PH:
                sp = min(MAXV, sp + SPEEDUP)            # hit: a bit faster
                vx, vy = aim(sp, angle(y, py), 1)
                aim_off = random.randint(-14, 14)
                bx = (LX + PW + 1) * F
            if vx > 0 and x + BALL >= RX and x <= RX + PW and cy - BALL < y < cy + PH:
                sp = min(MAXV, sp + SPEEDUP)
                vx, vy = aim(sp, angle(y, cy), -1)
                bx = (RX - BALL - 1) * F
            x, y = bx // F, by // F
            if x < 0 or x > SW - BALL:                  # missed: a point
                set_color(*BLACK)
                fill_rect(ox, oy, BALL, BALL)
                if x < 0:
                    cpu += 1
                    serve = -1
                else:
                    you += 1
                    serve = 1
                break
            set_color(*WHITE)                           # new ball first ...
            fill_rect(x, y, BALL, BALL)
            erase_old(ox, oy, x, y)                     # ... then erase the rest of the old one
            if ox < LX + PW + 2:                        # ball was over a paddle
                set_color(*YOU)
                fill_rect(LX, py, PW, PH)
            if ox + BALL > RX - 2:
                set_color(*CPU)
                fill_rect(RX, cy, PW, PH)
            paint()
            sleep(0.01)
    return you, cpu, False

# --- start ---
stats = load_stats()
if start_screen(stats):
    while True:
        you, cpu, quit = game()
        if quit:
            break
        stats[0 if you > cpu else 1] += 1
        save_stats(stats)
        bar(you, cpu, "YOU WIN!" if you > cpu else "CPU WINS")
        set_color(*WHITE)
        write(SW // 2 - 60, SH // 2, "ENTER: again")
        write(SW // 2 - 60, SH // 2 + 30, "CLEAR: quit")
        if wait_for(OK + QUIT) in QUIT:
            break
paint()
